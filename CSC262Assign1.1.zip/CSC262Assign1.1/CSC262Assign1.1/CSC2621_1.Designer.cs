﻿namespace CSC262Assign1._1
{
    partial class CSC2621_1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            btnStart = new Button();
            txbPlayerNumber = new TextBox();
            lblInstructions = new Label();
            lblResults = new Label();
            lblArrayInfo = new Label();
            SuspendLayout();
            // 
            // btnStart
            // 
            btnStart.BackColor = Color.LightBlue;
            btnStart.FlatAppearance.BorderColor = Color.Blue;
            btnStart.FlatAppearance.MouseDownBackColor = Color.Blue;
            btnStart.FlatAppearance.MouseOverBackColor = Color.Blue;
            btnStart.Font = new Font("Yu Gothic", 14.25F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btnStart.Location = new Point(318, 153);
            btnStart.Name = "btnStart";
            btnStart.Size = new Size(157, 39);
            btnStart.TabIndex = 0;
            btnStart.Text = "Start Testing";
            btnStart.UseVisualStyleBackColor = false;
            btnStart.Click += btnStart_Click;
            // 
            // txbPlayerNumber
            // 
            txbPlayerNumber.Font = new Font("Yu Gothic", 14.25F, FontStyle.Bold, GraphicsUnit.Point, 0);
            txbPlayerNumber.Location = new Point(340, 91);
            txbPlayerNumber.Name = "txbPlayerNumber";
            txbPlayerNumber.Size = new Size(117, 38);
            txbPlayerNumber.TabIndex = 1;
            // 
            // lblInstructions
            // 
            lblInstructions.AutoSize = true;
            lblInstructions.Font = new Font("Yu Gothic", 18F, FontStyle.Bold, GraphicsUnit.Point, 0);
            lblInstructions.Location = new Point(125, 45);
            lblInstructions.Name = "lblInstructions";
            lblInstructions.Size = new Size(557, 31);
            lblInstructions.TabIndex = 2;
            lblInstructions.Text = "Please enter a number between  1 and 10,000.";
            // 
            // lblResults
            // 
            lblResults.AutoSize = true;
            lblResults.Font = new Font("Yu Gothic", 15.75F, FontStyle.Bold, GraphicsUnit.Point, 0);
            lblResults.Location = new Point(137, 340);
            lblResults.Name = "lblResults";
            lblResults.Size = new Size(30, 27);
            lblResults.TabIndex = 3;
            lblResults.Text = "...";
            // 
            // lblArrayInfo
            // 
            lblArrayInfo.AutoSize = true;
            lblArrayInfo.Font = new Font("Yu Gothic", 15.75F, FontStyle.Bold, GraphicsUnit.Point, 0);
            lblArrayInfo.Location = new Point(136, 263);
            lblArrayInfo.Name = "lblArrayInfo";
            lblArrayInfo.Size = new Size(30, 27);
            lblArrayInfo.TabIndex = 4;
            lblArrayInfo.Text = "...";
            // 
            // CSC2621_1
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.MediumAquamarine;
            ClientSize = new Size(800, 450);
            Controls.Add(lblArrayInfo);
            Controls.Add(lblResults);
            Controls.Add(lblInstructions);
            Controls.Add(txbPlayerNumber);
            Controls.Add(btnStart);
            Name = "CSC2621_1";
            Text = "Assignment 1.1";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Button btnStart;
        private TextBox txbPlayerNumber;
        private Label lblInstructions;
        private Label lblResults;
        private Label lblArrayInfo;
    }
}
