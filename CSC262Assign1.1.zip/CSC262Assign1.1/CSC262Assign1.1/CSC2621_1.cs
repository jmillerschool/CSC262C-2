
using System.Diagnostics;

namespace CSC262Assign1._1
{
    public partial class CSC2621_1 : Form
    {
        public CSC2621_1()
        {
            InitializeComponent();
        }

        // I am trying to utilize what I learned in CSC202C# from you (thank you!) to keep my code clean and organized and use functions

       
        // create a function that uses the number the player entered in the text box to create the size of the array
        private void ArraySize()
        {
            // create an integer variable called iSize that holds the number the player entered in the text box
            // use int.Parse to convert the string to an integer 
            int iSize = int.Parse(txbPlayerNumber.Text);

            // create an integer array called iArray with the size of iSize
            int[] iArray = new int[iSize];

            // create a random number generator so we can fill the array with random numbers
            Random random = new Random();

            // create a for loop that goes from 0 to iSize 
            for (int i = 0; i < iSize; i++)
            {
                // fill the array with random numbers between 1 and 10 
                iArray[i] = random.Next(1, 11);
            }

            // create a loop so we can see how long it takes to run the program
            for (int i = 0; i < iSize; i++)
            {
                // create a delay of 1 second
               Thread.Sleep(100);
               
            }

            // display the array in the llbArrayResults label
            // use string.Join to convert the array to a string
            lblArrayInfo.Text = "Array: " + string.Join(", ", iArray);
        }




        private void btnStart_Click(object sender, EventArgs e)
        {
            // create a new stopwatch instance called watch
            Stopwatch watch = new Stopwatch();

            // start the stopwatch
            watch.Start();

            // call the function to create an array with the number the player entered in the text box and the random numbers to fill the array
            ArraySize();

            // stop the stopwatch
            watch.Stop();

            // display the time it took to run the program in the label
            lblResults.Text = "Time: " + watch.ElapsedMilliseconds + " ms";




        }
    }
}
