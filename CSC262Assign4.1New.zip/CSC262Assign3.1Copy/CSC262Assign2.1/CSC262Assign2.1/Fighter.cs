﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CSC262Assign2._1
{
    public class Fighter : Character
    {
        // VARIABLES
        public string WeaponType { get; set; }

        public int ArmorLevel { get; set; }

        // CONSTRUCTORS

        public Fighter(string playerName, string characterName, string chosenRace, string chosenClass, bool isPlayable, string weaponType, int armorLevel)
            : base(playerName, characterName, chosenRace, chosenClass, isPlayable)
        {
            WeaponType = weaponType;
            ArmorLevel = armorLevel;
        }

        // override the CharacterInfo method to include the weapon type and armor level
        public override string CharacterInfo()
        {
            return WeaponType;
        }
        // override the Attack method to include the weapon type
        public override string Attack()
        {
            return $"{CharacterName} uses a {WeaponType} to attack!";
        }

    }
}
