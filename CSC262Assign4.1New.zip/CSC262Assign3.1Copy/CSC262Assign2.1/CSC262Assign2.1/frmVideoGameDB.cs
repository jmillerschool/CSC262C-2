﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SQLite;
using System.Drawing;
using System.Linq;
using System.Security.AccessControl;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CSC262Assign2._1
{
    public partial class frmVideoGameDB : Form
    {
        // VARIABLES
        private string strObPath = "VideoGame.db";
                
        public frmVideoGameDB()
        {            
            InitializeComponent();
        }

        private void frmVideoGameDB_Load(object sender, EventArgs e)
        {
            // create the database using the function InitialiseDatabase that i made
            //InitialiseDatabase();

            //AddCharacter("Jennifer", "Sam", "Ork","Spellcaster",false);
           // AddCharacter("John", "Bob", "Slime", "Fighter", true);
            //AddCharacter("Mary", "Sally", "Spider", "Healer", true);

            // load the character from the database
            LoadCharacter();
        }



        // this function will create the sqlite database
        private void InitialiseDatabase()
        {
            // if the database file does not exist, create it
            //if (File.Exists(strObPath))

            // if the database file does not exist, create it    
            SQLiteConnection.CreateFile(strObPath);

            // create the database tables
            using (SQLiteConnection conn = new SQLiteConnection($"Data Source={strObPath}; Version=3;"))
            {
                // open the connection to the database
                conn.Open();

                // create the table for my character creation
                string strCreateTableQuerry = @"CREATE TABLE IF NOT EXISTS tblVideoGame(
                                                    pkCharacterNum INTEGER PRIMARY KEY AUTOINCREMENT,
                                                    PlayerName TEXT NOT NULL,
                                                    CharacterName TEXT NOT NULL,
                                                    Race TEXT NOT NULL,
                                                    Class TEXT NOT NULL,
                                                    IsPlayable BIT,
                                                    fkUser INT
                                                    );";

                // create the table for the video game 
                using (SQLiteCommand cmd = new SQLiteCommand(strCreateTableQuerry, conn))
                {
                    // use the command to execute the query 
                    cmd.ExecuteNonQuery();
                }               
            }

            // create a message box to show that the database has been created
            MessageBox.Show("Database Created");
        }



        // this function will add a character to the database
        private void AddCharacter(string playerName, string characterName, string raceName, string className, bool isPlayable)
        {
            // create the database if it does not exist
            using (SQLiteConnection conn = new SQLiteConnection($"Data Source={strObPath}; Version=3;"))
            {
                // open the connection to the database
                conn.Open();

                // create the table for my character creation
                string strInsertQuery = @"INSERT INTO tblVideoGame
                                            (PlayerName,CharacterName,Race,Class,IsPlayable)
                                            VALUES(@PlayerName,@CharacterName,@Race,@Class,@IsPlayable);";

                // create the table for the video game
                using (SQLiteCommand cmd = new SQLiteCommand(strInsertQuery, conn))
                {
                    // add all the values to the command
                    cmd.Parameters.AddWithValue("@PlayerName", playerName);
                    cmd.Parameters.AddWithValue("@CharacterName", characterName);
                    cmd.Parameters.AddWithValue("@Race", raceName);
                    cmd.Parameters.AddWithValue("@Class", className);
                    cmd.Parameters.AddWithValue("@IsPlayable", isPlayable);

                    // end the query
                    cmd.ExecuteNonQuery();

                }
            }
        }



        // create a function to load the character from the database
        private void LoadCharacter()
        {
            // create the database if it does not exist
            using (SQLiteConnection conn = new SQLiteConnection($"Data Source={strObPath}; Version=3;"))
            {
                // open the connection to the database
                conn.Open();

                // create a string to hold the query
                string strQuery = @"SELECT * FROM tblVideoGame;";

                using (SQLiteDataAdapter adapter = new SQLiteDataAdapter(strQuery, conn))
                {
                    DataTable dt = new DataTable();
                    adapter.Fill(dt);

                    // set the data source of the data grid view to the data table
                    dgbVideoGame.DataSource = dt;
                }
            }
        }
    }
}
