﻿namespace CSC262Assign2._1
{
    partial class Charactor
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            lblPlayerName = new Label();
            lblCharactorName = new Label();
            lblRace = new Label();
            lblClass = new Label();
            cbxIsPlayable = new CheckBox();
            lblIsPlayable = new Label();
            btnEnter = new Button();
            lbxCharacterInfo = new ListBox();
            tbxName = new TextBox();
            tbxCharacter = new TextBox();
            nubRace = new NumericUpDown();
            nubClass = new NumericUpDown();
            lblRaceInfo = new Label();
            lblClassInfo = new Label();
            ((System.ComponentModel.ISupportInitialize)nubRace).BeginInit();
            ((System.ComponentModel.ISupportInitialize)nubClass).BeginInit();
            SuspendLayout();
            // 
            // lblPlayerName
            // 
            lblPlayerName.AutoSize = true;
            lblPlayerName.Font = new Font("Yu Gothic", 14.25F, FontStyle.Bold, GraphicsUnit.Point, 0);
            lblPlayerName.Location = new Point(143, 47);
            lblPlayerName.Name = "lblPlayerName";
            lblPlayerName.Size = new Size(233, 25);
            lblPlayerName.TabIndex = 0;
            lblPlayerName.Text = "Please enter your name:";
            // 
            // lblCharactorName
            // 
            lblCharactorName.AutoSize = true;
            lblCharactorName.Font = new Font("Yu Gothic", 14.25F, FontStyle.Bold, GraphicsUnit.Point, 0);
            lblCharactorName.Location = new Point(43, 103);
            lblCharactorName.Name = "lblCharactorName";
            lblCharactorName.Size = new Size(338, 25);
            lblCharactorName.TabIndex = 1;
            lblCharactorName.Text = "Please enter your Characters name:";
            // 
            // lblRace
            // 
            lblRace.AutoSize = true;
            lblRace.Font = new Font("Yu Gothic", 14.25F, FontStyle.Bold, GraphicsUnit.Point, 0);
            lblRace.Location = new Point(47, 162);
            lblRace.Name = "lblRace";
            lblRace.Size = new Size(329, 25);
            lblRace.TabIndex = 2;
            lblRace.Text = "Please enter chosen Race number:";
            // 
            // lblClass
            // 
            lblClass.AutoSize = true;
            lblClass.Font = new Font("Yu Gothic", 14.25F, FontStyle.Bold, GraphicsUnit.Point, 0);
            lblClass.Location = new Point(47, 227);
            lblClass.Name = "lblClass";
            lblClass.Size = new Size(334, 25);
            lblClass.TabIndex = 3;
            lblClass.Text = "Please enter chosen Class number:";
            // 
            // cbxIsPlayable
            // 
            cbxIsPlayable.AutoSize = true;
            cbxIsPlayable.Font = new Font("Yu Gothic", 15.75F, FontStyle.Bold, GraphicsUnit.Point, 0);
            cbxIsPlayable.Location = new Point(429, 288);
            cbxIsPlayable.Name = "cbxIsPlayable";
            cbxIsPlayable.Size = new Size(118, 31);
            cbxIsPlayable.TabIndex = 4;
            cbxIsPlayable.Text = "Playable";
            cbxIsPlayable.UseVisualStyleBackColor = true;
            // 
            // lblIsPlayable
            // 
            lblIsPlayable.AutoSize = true;
            lblIsPlayable.Font = new Font("Yu Gothic", 14.25F, FontStyle.Bold, GraphicsUnit.Point, 0);
            lblIsPlayable.Location = new Point(-6, 291);
            lblIsPlayable.Name = "lblIsPlayable";
            lblIsPlayable.Size = new Size(387, 25);
            lblIsPlayable.TabIndex = 5;
            lblIsPlayable.Text = "Please check if the Character is playable:";
            // 
            // btnEnter
            // 
            btnEnter.Font = new Font("Yu Gothic", 15.75F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btnEnter.Location = new Point(589, 259);
            btnEnter.Name = "btnEnter";
            btnEnter.Size = new Size(244, 57);
            btnEnter.TabIndex = 6;
            btnEnter.Text = "Enter Character";
            btnEnter.UseVisualStyleBackColor = true;
            btnEnter.Click += btnEnter_Click;
            // 
            // lbxCharacterInfo
            // 
            lbxCharacterInfo.Font = new Font("Yu Gothic", 11.25F, FontStyle.Bold, GraphicsUnit.Point, 0);
            lbxCharacterInfo.FormattingEnabled = true;
            lbxCharacterInfo.ItemHeight = 19;
            lbxCharacterInfo.Location = new Point(12, 364);
            lbxCharacterInfo.Name = "lbxCharacterInfo";
            lbxCharacterInfo.Size = new Size(821, 194);
            lbxCharacterInfo.TabIndex = 7;
            // 
            // tbxName
            // 
            tbxName.Font = new Font("Yu Gothic", 14.25F, FontStyle.Bold, GraphicsUnit.Point, 0);
            tbxName.Location = new Point(403, 44);
            tbxName.Name = "tbxName";
            tbxName.Size = new Size(128, 38);
            tbxName.TabIndex = 8;
            // 
            // tbxCharacter
            // 
            tbxCharacter.Font = new Font("Yu Gothic", 14.25F, FontStyle.Bold, GraphicsUnit.Point, 0);
            tbxCharacter.Location = new Point(403, 100);
            tbxCharacter.Name = "tbxCharacter";
            tbxCharacter.Size = new Size(128, 38);
            tbxCharacter.TabIndex = 9;
            // 
            // nubRace
            // 
            nubRace.Font = new Font("Yu Gothic", 15.75F, FontStyle.Bold, GraphicsUnit.Point, 0);
            nubRace.Location = new Point(429, 158);
            nubRace.Margin = new Padding(2);
            nubRace.Name = "nubRace";
            nubRace.Size = new Size(65, 41);
            nubRace.TabIndex = 10;
            // 
            // nubClass
            // 
            nubClass.Font = new Font("Yu Gothic", 15.75F, FontStyle.Bold, GraphicsUnit.Point, 0);
            nubClass.Location = new Point(429, 227);
            nubClass.Margin = new Padding(2);
            nubClass.Name = "nubClass";
            nubClass.Size = new Size(65, 41);
            nubClass.TabIndex = 12;
            // 
            // lblRaceInfo
            // 
            lblRaceInfo.AutoSize = true;
            lblRaceInfo.BackColor = Color.SkyBlue;
            lblRaceInfo.Font = new Font("Yu Gothic", 14.25F, FontStyle.Bold, GraphicsUnit.Point, 0);
            lblRaceInfo.Location = new Point(735, 42);
            lblRaceInfo.Name = "lblRaceInfo";
            lblRaceInfo.Padding = new Padding(10);
            lblRaceInfo.Size = new Size(116, 145);
            lblRaceInfo.TabIndex = 13;
            lblRaceInfo.Text = "Races: \r\n1) Orc\r\n2) Goblin\r\n3) Spider\r\n4) Slime";
            // 
            // lblClassInfo
            // 
            lblClassInfo.AutoSize = true;
            lblClassInfo.BackColor = Color.PowderBlue;
            lblClassInfo.Font = new Font("Yu Gothic", 14.25F, FontStyle.Bold, GraphicsUnit.Point, 0);
            lblClassInfo.Location = new Point(541, 42);
            lblClassInfo.Name = "lblClassInfo";
            lblClassInfo.Padding = new Padding(10);
            lblClassInfo.Size = new Size(158, 145);
            lblClassInfo.TabIndex = 14;
            lblClassInfo.Text = "Classes:\r\n1) Healer\r\n2) Fighter\r\n3) Spellcaster\r\n4) Ranger";
            // 
            // Charactor
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.LightSteelBlue;
            ClientSize = new Size(863, 590);
            Controls.Add(lblClassInfo);
            Controls.Add(lblRaceInfo);
            Controls.Add(nubClass);
            Controls.Add(nubRace);
            Controls.Add(tbxCharacter);
            Controls.Add(tbxName);
            Controls.Add(lbxCharacterInfo);
            Controls.Add(btnEnter);
            Controls.Add(lblIsPlayable);
            Controls.Add(cbxIsPlayable);
            Controls.Add(lblClass);
            Controls.Add(lblRace);
            Controls.Add(lblCharactorName);
            Controls.Add(lblPlayerName);
            Name = "Charactor";
            Text = "Charactor Creator";
            ((System.ComponentModel.ISupportInitialize)nubRace).EndInit();
            ((System.ComponentModel.ISupportInitialize)nubClass).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label lblPlayerName;
        private Label lblCharactorName;
        private Label lblRace;
        private Label lblClass;
        private CheckBox cbxIsPlayable;
        private Label lblIsPlayable;
        private Button btnEnter;
        private ListBox lbxCharacterInfo;
        private TextBox tbxName;
        private TextBox tbxCharacter;
        private NumericUpDown nubRace;
        private NumericUpDown nubClass;
        private Label lblRaceInfo;
        private Label lblClassInfo;
    }
}
