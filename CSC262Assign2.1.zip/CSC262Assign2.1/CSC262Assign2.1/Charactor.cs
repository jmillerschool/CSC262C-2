namespace CSC262Assign2._1
{
    public partial class Charactor : Form
    {
        public Charactor()
        {
            InitializeComponent();
        }

        private void btnEnter_Click(object sender, EventArgs e)
        {
            // create a new instance of the character with the values from the text boxes, numbers, and check boxes
            Character character = new Character( tbxName.Text, tbxCharacter.Text, (int)nubRace.Value, (int)nubClass.Value, cbxIsPlayable.Checked);

            // call the function CharacterInfo to display the character information in the lbxCharacterInfo
            lbxCharacterInfo.Items.Add(character.CharacterInfo());

            // call the Goodbye function to display the goodbye message in a message box
            MessageBox.Show(character.GoodbyeMessage());

        }
    }
}
