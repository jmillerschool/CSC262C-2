﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CSC262Assign2._1
{
    class Character
    {
        // VARIABLES

        // create a int called chosenRaceNumber to store the number choosen
        private int chosenRaceNumber;

        // create a int called chosenClassNumber to store the number choosen
        private int chosenClassNumber;

        // create a string for the player name with get and set methods 
        private string PlayerName { get; set; }

        // create a string for the character name
        private string CharacterName { get; set; }

        // create an int for the chosen race
        private int ChosenRace
        {
            // create a get to return chosenRace
            get { return chosenRaceNumber; }

            // create a set to assign chosenRace
            set
            {
                // check if the value is greater than 0 
                if (value > 0)
                {
                    // assign the value to chosenRace
                    chosenRaceNumber = value;
                }
                else
                {
                    // assign the value to chosenRace to the default value of 1
                    chosenRaceNumber = 1;
                }
            }
        }

        // create an int for the chosen class
        private int ChosenClass
        {
            // create a get to return chosenClass
            get { return chosenClassNumber; }

            // create a set to assign chosenClass
            set
            {
                // check if the value is greater than 0 
                if (value > 0)
                {
                    // assign the value to chosenClass
                    chosenClassNumber = value;
                }
                else
                {
                    // assign the value to chosenClass to the default value of 1
                    chosenClassNumber = 1;
                }
            }
        }

        // create a boolean for the is playable
        public bool IsPlayable { get; set; }

        // CONSTRUCTORS
        public Character(string playerName, string characterName, int chosenRace, int chosenClass, bool isPlayable)
        {
            // assign the values to the variables
            PlayerName = playerName;
            CharacterName = characterName;
            ChosenRace = chosenRace;
            ChosenClass = chosenClass;
            IsPlayable = isPlayable;

        }


        // FUNCTIONS/METHODS

        // create a function called CharacterInfo that returns a string
        public string CharacterInfo()
        {
            return PlayerName + " your characters name is " + CharacterName + " , they are a  " + ChosenRace +  " with the class of " + ChosenClass + " and your character is " + IsPlayable;
        }

        // create a function called goodbye message that returns a string
        public string GoodbyeMessage()
        {
            return "Goodbye " + PlayerName + " your character " + CharacterName + " has been created";
        }


    }
}
