﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CSC262Assign2._1
{
    public class Healer : Character
    {
        // VARIABLES

        // create a variable for the healing type
        public string Holy {get; set; }

        // create a variable for the mana
        public int Mana { get; set; }

        // CONSTRUCTORS
        public Healer(string playerName, string characterName, string chosenRace, string chosenClass, bool isPlayable, string holy, int mana)   : base(playerName, characterName, chosenRace, chosenClass, isPlayable)
        {
            Holy = holy;
            Mana = mana;
        }

        // FUNCTIONS/METHODS

        // override the CharacterInfo method to include the healing type
        public override string CharacterInfo()
        {
            return PlayerName + "your characters name is " + CharacterName + " , they are a(n) " + Race + " with the class of " + Class + ", your character is " + IsPlayable + " and they have " + Holy +" healing type";
        }

        //overload the CharacterInfo method to include the spec2



        // override the Attack method to include the mana
        public override string Attack()
        {
            return PlayerName + " your character " + CharacterName + " has " + Mana + " mana";
        }
    }
}
