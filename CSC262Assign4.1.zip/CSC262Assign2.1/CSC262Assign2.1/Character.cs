﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CSC262Assign2._1
{
    public class Character
    {
        // VARIABLES
        // create a string called race to hold the chosen race
        public string Race { get; set; }

        // create a string called class to hold the chosen class
        public string Class { get; set; }

        // create a string for the player name with get and set methods 
        public string PlayerName { get; set; }

        // create a stri
        // ng for the character name
        public string CharacterName { get; set; }

        // create a boolean for the is playable
        public bool IsPlayable { get; set; }

       

        // CONSTRUCTORS
        public Character(string playerName, string characterName, string chosenRace, string chosenClass, bool isPlayable)
        {
            // assign the values to the variables
            PlayerName = playerName;
            CharacterName = characterName;
            Race = chosenRace;
            Class = chosenClass;
            IsPlayable = isPlayable;      
        }


        // FUNCTIONS/METHODS

        // create a function called CharacterInfo that returns a string
        public virtual string CharacterInfo()
        {
            return PlayerName + " your characters name is " + CharacterName + " , they are a(n) " + Race +  " with the class of " + Class + " and your character is  \r\n "  + IsPlayable;
        }

        // create a function called CharacterInfo that returns a string that we can overload
        public virtual string CharacterInfo(int spec2IsHigh)
        {                   
            
            if (spec2IsHigh > 5)
            {
                return PlayerName + " your characters name is " + CharacterName + " , they are a(n) " + Race + " with the class of " + Class  + "\n" + " and your character is " + IsPlayable + ". " + PlayerName + " wow your character " + CharacterName + " is really strong with a " + spec2IsHigh + " strength level";
            }
            else
            {
                return PlayerName + " your characters name is " + CharacterName + " , they are a(n) " + Race + " with the class of " + Class +  "\n and your character is " + IsPlayable + ". " + PlayerName + " your character " + CharacterName + " has a  " + spec2IsHigh + " strength level";
            }
        }


        // create a function called Attack that returns a string
        public virtual string Attack()
        {
            return CharacterName + " attacks";
        }

        // create a function called goodbye message that returns a string
        public string GoodbyeMessage()
        {
            return "Goodbye " + PlayerName + " your character " + CharacterName + " has been created";
        }


    }
}
