﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Web;
using System.Windows.Forms;
// add the using statement for the SQL connection
using Microsoft.Data.SqlClient;

namespace CSC262Assign2._1
{
    public partial class frmVideoGameShow : Form
    {
        public frmVideoGameShow()
        {
            InitializeComponent();
        }

        private void frmVideoGameShow_Load(object sender, EventArgs e)
        {
            // VARIABLES

            // create a string to hold the connection string to show my database
            string strConnString = @"Data Source=(LocalDB)\MSSQLLocalDB,AttachDbFilename=G:\CSC262C#2\CSC262Assign2.1\CSC262Assign2.1\VideoGame.mdf;Integrated Security=True;Connect Timeout=30;";

            // create an string to hold the query to select all from the tblVideoGame table
            string strQuery = "SELECT * FROM tblVideoGame";

            // create a new instance of the SqlConnection class with the connection string
            using (SqlConnection connection = new SqlConnection(strConnString))
            {               
                // open the connection
                connection.Open();

                // set up the code to run the query 
                using (SqlCommand cmd = new SqlCommand())
                {
                    // data addapter so the data can be displayed in the datagridview

                    SqlDataAdapter adapter = new SqlDataAdapter(strQuery, strConnString);

                    DataTable table = new DataTable();

                    adapter.Fill(table);

                    dgVideoGame.DataSource = table;
                }

                
            }

        }
    }
}
