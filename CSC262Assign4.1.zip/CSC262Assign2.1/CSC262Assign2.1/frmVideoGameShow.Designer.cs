﻿namespace CSC262Assign2._1
{
    partial class frmVideoGameShow
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            dgVideoGame = new DataGridView();
            ((System.ComponentModel.ISupportInitialize)dgVideoGame).BeginInit();
            SuspendLayout();
            // 
            // dgVideoGame
            // 
            dgVideoGame.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dgVideoGame.Location = new Point(62, 79);
            dgVideoGame.Name = "dgVideoGame";
            dgVideoGame.Size = new Size(696, 276);
            dgVideoGame.TabIndex = 0;
            // 
            // frmVideoGameShow
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 450);
            Controls.Add(dgVideoGame);
            Name = "frmVideoGameShow";
            Text = "frmVideoGameShow";
            Load += frmVideoGameShow_Load;
            ((System.ComponentModel.ISupportInitialize)dgVideoGame).EndInit();
            ResumeLayout(false);
        }

        #endregion

        private DataGridView dgVideoGame;
    }
}