﻿namespace CSC262Assign2._1
{
    partial class VideoGame
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            lblPlayerName = new Label();
            lblCharactorName = new Label();
            lblRace = new Label();
            lblClass = new Label();
            cbxIsPlayable = new CheckBox();
            lblIsPlayable = new Label();
            btnEnter = new Button();
            lbxCharacterInfo = new ListBox();
            tbxName = new TextBox();
            tbxCharacter = new TextBox();
            cmbRace = new ComboBox();
            cmbClass = new ComboBox();
            lblRaceBonus = new Label();
            tbxRaceBonus = new TextBox();
            label1 = new Label();
            tbxClassBonus = new TextBox();
            lbxClassInfo = new ListBox();
            lblSpec1 = new Label();
            lblSpec2 = new Label();
            tbxSpec1 = new TextBox();
            nudSpec2 = new NumericUpDown();
            ((System.ComponentModel.ISupportInitialize)nudSpec2).BeginInit();
            SuspendLayout();
            // 
            // lblPlayerName
            // 
            lblPlayerName.AutoSize = true;
            lblPlayerName.Font = new Font("Yu Gothic", 14.25F, FontStyle.Bold, GraphicsUnit.Point, 0);
            lblPlayerName.Location = new Point(117, 24);
            lblPlayerName.Name = "lblPlayerName";
            lblPlayerName.Size = new Size(233, 25);
            lblPlayerName.TabIndex = 0;
            lblPlayerName.Text = "Please enter your name:";
            // 
            // lblCharactorName
            // 
            lblCharactorName.AutoSize = true;
            lblCharactorName.Font = new Font("Yu Gothic", 14.25F, FontStyle.Bold, GraphicsUnit.Point, 0);
            lblCharactorName.Location = new Point(12, 83);
            lblCharactorName.Name = "lblCharactorName";
            lblCharactorName.Size = new Size(338, 25);
            lblCharactorName.TabIndex = 1;
            lblCharactorName.Text = "Please enter your Characters name:";
            // 
            // lblRace
            // 
            lblRace.AutoSize = true;
            lblRace.Font = new Font("Yu Gothic", 14.25F, FontStyle.Bold, GraphicsUnit.Point, 0);
            lblRace.Location = new Point(97, 144);
            lblRace.Name = "lblRace";
            lblRace.Size = new Size(253, 25);
            lblRace.TabIndex = 2;
            lblRace.Text = "Please enter chosen Race:";
            // 
            // lblClass
            // 
            lblClass.AutoSize = true;
            lblClass.Font = new Font("Yu Gothic", 14.25F, FontStyle.Bold, GraphicsUnit.Point, 0);
            lblClass.Location = new Point(92, 205);
            lblClass.Name = "lblClass";
            lblClass.Size = new Size(258, 25);
            lblClass.TabIndex = 3;
            lblClass.Text = "Please enter chosen Class:";
            // 
            // cbxIsPlayable
            // 
            cbxIsPlayable.AutoSize = true;
            cbxIsPlayable.Font = new Font("Yu Gothic", 14.25F, FontStyle.Bold, GraphicsUnit.Point, 0);
            cbxIsPlayable.Location = new Point(257, 297);
            cbxIsPlayable.Name = "cbxIsPlayable";
            cbxIsPlayable.Size = new Size(109, 29);
            cbxIsPlayable.TabIndex = 4;
            cbxIsPlayable.Text = "Playable";
            cbxIsPlayable.UseVisualStyleBackColor = true;
            // 
            // lblIsPlayable
            // 
            lblIsPlayable.AutoSize = true;
            lblIsPlayable.Font = new Font("Yu Gothic", 14.25F, FontStyle.Bold, GraphicsUnit.Point, 0);
            lblIsPlayable.Location = new Point(30, 298);
            lblIsPlayable.Name = "lblIsPlayable";
            lblIsPlayable.Size = new Size(210, 25);
            lblIsPlayable.TabIndex = 5;
            lblIsPlayable.Text = "Character is playable:";
            // 
            // btnEnter
            // 
            btnEnter.Font = new Font("Yu Gothic", 15.75F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btnEnter.Location = new Point(513, 281);
            btnEnter.Name = "btnEnter";
            btnEnter.Size = new Size(215, 57);
            btnEnter.TabIndex = 6;
            btnEnter.Text = "Enter Character";
            btnEnter.UseVisualStyleBackColor = true;
            btnEnter.Click += btnEnter_Click;
            // 
            // lbxCharacterInfo
            // 
            lbxCharacterInfo.Font = new Font("Yu Gothic", 9F, FontStyle.Bold, GraphicsUnit.Point, 0);
            lbxCharacterInfo.FormattingEnabled = true;
            lbxCharacterInfo.Location = new Point(12, 345);
            lbxCharacterInfo.Name = "lbxCharacterInfo";
            lbxCharacterInfo.Size = new Size(908, 84);
            lbxCharacterInfo.TabIndex = 7;
            // 
            // tbxName
            // 
            tbxName.Font = new Font("Yu Gothic", 14.25F, FontStyle.Bold, GraphicsUnit.Point, 0);
            tbxName.Location = new Point(356, 21);
            tbxName.Name = "tbxName";
            tbxName.Size = new Size(128, 38);
            tbxName.TabIndex = 8;
            // 
            // tbxCharacter
            // 
            tbxCharacter.Font = new Font("Yu Gothic", 14.25F, FontStyle.Bold, GraphicsUnit.Point, 0);
            tbxCharacter.Location = new Point(356, 80);
            tbxCharacter.Name = "tbxCharacter";
            tbxCharacter.Size = new Size(128, 38);
            tbxCharacter.TabIndex = 9;
            // 
            // cmbRace
            // 
            cmbRace.Font = new Font("Yu Gothic", 14.25F, FontStyle.Bold, GraphicsUnit.Point, 0);
            cmbRace.FormattingEnabled = true;
            cmbRace.Items.AddRange(new object[] { "Goblin", "Ork", "Slime", "Spider" });
            cmbRace.Location = new Point(356, 141);
            cmbRace.Name = "cmbRace";
            cmbRace.Size = new Size(121, 33);
            cmbRace.TabIndex = 15;
            cmbRace.SelectedIndexChanged += cmbRace_SelectedIndexChanged;
            // 
            // cmbClass
            // 
            cmbClass.Font = new Font("Yu Gothic", 14.25F, FontStyle.Bold, GraphicsUnit.Point, 0);
            cmbClass.FormattingEnabled = true;
            cmbClass.Items.AddRange(new object[] { "Fighter", "Healer", "Ranger", "Spellcaster" });
            cmbClass.Location = new Point(356, 202);
            cmbClass.Name = "cmbClass";
            cmbClass.Size = new Size(121, 33);
            cmbClass.TabIndex = 16;
            cmbClass.SelectedIndexChanged += cmbClass_SelectedIndexChanged;
            // 
            // lblRaceBonus
            // 
            lblRaceBonus.AutoSize = true;
            lblRaceBonus.Font = new Font("Yu Gothic", 14.25F, FontStyle.Bold, GraphicsUnit.Point, 0);
            lblRaceBonus.Location = new Point(524, 24);
            lblRaceBonus.Name = "lblRaceBonus";
            lblRaceBonus.Size = new Size(126, 25);
            lblRaceBonus.TabIndex = 17;
            lblRaceBonus.Text = "Race Bonus:";
            // 
            // tbxRaceBonus
            // 
            tbxRaceBonus.Font = new Font("Yu Gothic", 14.25F, FontStyle.Bold, GraphicsUnit.Point, 0);
            tbxRaceBonus.Location = new Point(673, 21);
            tbxRaceBonus.Name = "tbxRaceBonus";
            tbxRaceBonus.Size = new Size(143, 38);
            tbxRaceBonus.TabIndex = 18;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Yu Gothic", 14.25F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label1.Location = new Point(524, 83);
            label1.Name = "label1";
            label1.Size = new Size(131, 25);
            label1.TabIndex = 19;
            label1.Text = "Class Bonus:";
            // 
            // tbxClassBonus
            // 
            tbxClassBonus.Font = new Font("Yu Gothic", 14.25F, FontStyle.Bold, GraphicsUnit.Point, 0);
            tbxClassBonus.Location = new Point(673, 83);
            tbxClassBonus.Name = "tbxClassBonus";
            tbxClassBonus.Size = new Size(143, 38);
            tbxClassBonus.TabIndex = 20;
            tbxClassBonus.TextChanged += tbxClassBonus_TextChanged;
            // 
            // lbxClassInfo
            // 
            lbxClassInfo.Font = new Font("Yu Gothic", 11.25F, FontStyle.Bold, GraphicsUnit.Point, 0);
            lbxClassInfo.FormattingEnabled = true;
            lbxClassInfo.ItemHeight = 19;
            lbxClassInfo.Location = new Point(12, 465);
            lbxClassInfo.Name = "lbxClassInfo";
            lbxClassInfo.Size = new Size(908, 99);
            lbxClassInfo.TabIndex = 21;
            // 
            // lblSpec1
            // 
            lblSpec1.AutoSize = true;
            lblSpec1.Font = new Font("Yu Gothic", 14.25F, FontStyle.Bold, GraphicsUnit.Point, 0);
            lblSpec1.Location = new Point(559, 149);
            lblSpec1.Name = "lblSpec1";
            lblSpec1.Size = new Size(85, 25);
            lblSpec1.TabIndex = 22;
            lblSpec1.Text = "Spec 1: ";
            // 
            // lblSpec2
            // 
            lblSpec2.AutoSize = true;
            lblSpec2.Font = new Font("Yu Gothic", 14.25F, FontStyle.Bold, GraphicsUnit.Point, 0);
            lblSpec2.Location = new Point(559, 205);
            lblSpec2.Name = "lblSpec2";
            lblSpec2.Size = new Size(80, 25);
            lblSpec2.TabIndex = 23;
            lblSpec2.Text = "Spec 2:\r\n";
            // 
            // tbxSpec1
            // 
            tbxSpec1.Font = new Font("Yu Gothic", 14.25F, FontStyle.Bold, GraphicsUnit.Point, 0);
            tbxSpec1.Location = new Point(673, 141);
            tbxSpec1.Name = "tbxSpec1";
            tbxSpec1.Size = new Size(143, 38);
            tbxSpec1.TabIndex = 24;
            // 
            // nudSpec2
            // 
            nudSpec2.Font = new Font("Yu Gothic", 14.25F, FontStyle.Bold, GraphicsUnit.Point, 0);
            nudSpec2.Location = new Point(700, 203);
            nudSpec2.Margin = new Padding(2);
            nudSpec2.Name = "nudSpec2";
            nudSpec2.Size = new Size(93, 38);
            nudSpec2.TabIndex = 25;
            // 
            // VideoGame
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.LightSteelBlue;
            ClientSize = new Size(951, 586);
            Controls.Add(nudSpec2);
            Controls.Add(tbxSpec1);
            Controls.Add(lblSpec2);
            Controls.Add(lblSpec1);
            Controls.Add(lbxClassInfo);
            Controls.Add(tbxClassBonus);
            Controls.Add(label1);
            Controls.Add(tbxRaceBonus);
            Controls.Add(lblRaceBonus);
            Controls.Add(cmbClass);
            Controls.Add(cmbRace);
            Controls.Add(tbxCharacter);
            Controls.Add(tbxName);
            Controls.Add(lbxCharacterInfo);
            Controls.Add(btnEnter);
            Controls.Add(lblIsPlayable);
            Controls.Add(cbxIsPlayable);
            Controls.Add(lblClass);
            Controls.Add(lblRace);
            Controls.Add(lblCharactorName);
            Controls.Add(lblPlayerName);
            Name = "VideoGame";
            Text = "Charactor Creator";
            ((System.ComponentModel.ISupportInitialize)nudSpec2).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label lblPlayerName;
        private Label lblCharactorName;
        private Label lblRace;
        private Label lblClass;
        private CheckBox cbxIsPlayable;
        private Label lblIsPlayable;
        private Button btnEnter;
        private ListBox lbxCharacterInfo;
        private TextBox tbxName;
        private TextBox tbxCharacter;
        private ComboBox cmbRace;
        private ComboBox cmbClass;
        private Label lblRaceBonus;
        private TextBox tbxRaceBonus;
        private Label label1;
        private TextBox tbxClassBonus;
        private ListBox lbxClassInfo;
        private Label lblSpec1;
        private Label lblSpec2;
        private TextBox tbxSpec1;
        private NumericUpDown nudSpec2;
    }
}
