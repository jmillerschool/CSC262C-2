namespace CSC262Assign2._1
{
    public partial class VideoGame : Form
    {
        public VideoGame()
        {
            InitializeComponent();
        }

        private void btnEnter_Click(object sender, EventArgs e)
        {
            
           ;
            

            // create a new instance of the character with the values from the text boxes, numbers, and check boxes
            Character character = new Character(tbxName.Text, tbxCharacter.Text, cmbRace.Text, cmbClass.Text, cbxIsPlayable.Checked);

            // call the function CharacterInfo to display the character information in the lbxCharacterInfo
            lbxCharacterInfo.Items.Add(character.CharacterInfo());

            // call the Attack function to display the attack message in the lbxCharacterInfo
            lbxClassInfo.Items.Add(character.Attack());

            // call the Goodbye function to display the goodbye message in a message box
            MessageBox.Show(character.GoodbyeMessage());

        }

        // create a metod for the cmbRace selected index changed
        private void cmbRace_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (cmbRace.Text == "Ork")
            {
                tbxRaceBonus.Text = "Str +2";
            }
            else if (cmbRace.Text == "Slime")
            {
                tbxRaceBonus.Text = "Int +2";
            }
            else if (cmbRace.Text == "Spider")
            {
                tbxRaceBonus.Text = "Agility +2";
            }
            else if (cmbRace.Text == "Goblin")
            {
                tbxRaceBonus.Text = "Luck +2";
            }
            // If nothing is entered create a message box with error
            else
            {
                tbxRaceBonus.Text = "Please enter a race";
            }
        }

        private void tbxClassBonus_TextChanged(object sender, EventArgs e)
        {

        }

        private void cmbClass_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (cmbClass.Text == "Fighter")
            {
                tbxClassBonus.Text = "Str +2";
                lblSpec1.Text = "Weapon";
                lblSpec2.Text = "Armor Level";
            }
            else if (cmbClass.Text == "Spellcaster")
            {
                tbxClassBonus.Text = "Int +2";
                lblSpec1.Text = "Element";
                lblSpec2.Text = "Mana";
            }
            else if (cmbClass.Text == "Ranger")
            {
                tbxClassBonus.Text = "Agility +2";
                lblSpec1.Text = "Weapon";
                lblSpec2.Text = "Stealth";
            }
            else if (cmbClass.Text == "Healer")
            {
                tbxClassBonus.Text = "Luck +2";
                lblSpec1.Text = "Holy";
                lblSpec2.Text = "Mana";
            }
        }
    }
}

