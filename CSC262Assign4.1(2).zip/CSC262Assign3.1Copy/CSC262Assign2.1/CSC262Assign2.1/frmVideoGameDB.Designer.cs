﻿namespace CSC262Assign2._1
{
    partial class frmVideoGameDB
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            dgbVideoGame = new DataGridView();
            lblInstruction = new Label();
            ((System.ComponentModel.ISupportInitialize)dgbVideoGame).BeginInit();
            SuspendLayout();
            // 
            // dgbVideoGame
            // 
            dgbVideoGame.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dgbVideoGame.Location = new Point(60, 97);
            dgbVideoGame.Name = "dgbVideoGame";
            dgbVideoGame.Size = new Size(698, 228);
            dgbVideoGame.TabIndex = 0;
            // 
            // lblInstruction
            // 
            lblInstruction.AutoSize = true;
            lblInstruction.Font = new Font("Yu Gothic", 15.75F, FontStyle.Bold, GraphicsUnit.Point, 0);
            lblInstruction.Location = new Point(203, 35);
            lblInstruction.Name = "lblInstruction";
            lblInstruction.Size = new Size(342, 27);
            lblInstruction.TabIndex = 1;
            lblInstruction.Text = "This is where chacters are made";
            // 
            // frmVideoGameDB
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.LightSteelBlue;
            ClientSize = new Size(800, 450);
            Controls.Add(lblInstruction);
            Controls.Add(dgbVideoGame);
            Name = "frmVideoGameDB";
            Text = "frmVideoGameDB";
            Load += frmVideoGameDB_Load;
            ((System.ComponentModel.ISupportInitialize)dgbVideoGame).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private DataGridView dgbVideoGame;
        private Label lblInstruction;
    }
}