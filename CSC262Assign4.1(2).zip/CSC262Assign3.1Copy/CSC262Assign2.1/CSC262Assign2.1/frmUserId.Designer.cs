﻿namespace CSC262Assign2._1
{
    partial class frmUserId
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            dgvUserInfo = new DataGridView();
            lblUserIdInstruction = new Label();
            ((System.ComponentModel.ISupportInitialize)dgvUserInfo).BeginInit();
            SuspendLayout();
            // 
            // dgvUserInfo
            // 
            dgvUserInfo.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dgvUserInfo.Location = new Point(92, 78);
            dgvUserInfo.Name = "dgvUserInfo";
            dgvUserInfo.Size = new Size(644, 265);
            dgvUserInfo.TabIndex = 0;
            // 
            // lblUserIdInstruction
            // 
            lblUserIdInstruction.AutoSize = true;
            lblUserIdInstruction.Font = new Font("Yu Gothic", 15.75F, FontStyle.Bold, GraphicsUnit.Point, 0);
            lblUserIdInstruction.Location = new Point(212, 31);
            lblUserIdInstruction.Name = "lblUserIdInstruction";
            lblUserIdInstruction.Size = new Size(375, 27);
            lblUserIdInstruction.TabIndex = 1;
            lblUserIdInstruction.Text = "This is were you can make a user Id";
            // 
            // frmUserId
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.LemonChiffon;
            ClientSize = new Size(800, 450);
            Controls.Add(lblUserIdInstruction);
            Controls.Add(dgvUserInfo);
            Name = "frmUserId";
            Text = "frmUserId";
            Load += frmUserId_Load;
            ((System.ComponentModel.ISupportInitialize)dgvUserInfo).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private DataGridView dgvUserInfo;
        private Label lblUserIdInstruction;
    }
}