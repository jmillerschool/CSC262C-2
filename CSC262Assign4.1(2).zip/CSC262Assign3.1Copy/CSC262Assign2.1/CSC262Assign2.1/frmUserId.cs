﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SQLite;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CSC262Assign2._1
{
    public partial class frmUserId : Form
    {

        // VARIABLES
        private string strObPath = "UserId.db";

        public frmUserId()
        {
            InitializeComponent();
        }

        private void frmUserId_Load(object sender, EventArgs e)
        {

        }

        // create a function that will create the sqlite database
        private void InitialiseDatabase()
        {

            // if the database file does not exist, create it    
            SQLiteConnection.CreateFile(strObPath);

            // create the database tables
            using (SQLiteConnection conn = new SQLiteConnection($"Data Source={strObPath}; Version=3;"))
            {
                // open the connection to the database
                conn.Open();

                // create the table for the userId
                string strCreateTableQuerry = @"CREATE TABLE IF NOT EXISTS tblUserId(
                                                    pkUser INTEGER PRIMARY KEY AUTOINCREMENT,
                                                    FirstName TEXT NOT NULL,
                                                    LastName TEXT NOT NULL,
                                                    UserName TEXT NOT NULL,
                                                    passward TEXT NOT NULL
                                                    );";

                // create the table for the userId
                using (SQLiteCommand cmd = new SQLiteCommand(strCreateTableQuerry, conn))
                {
                    // use the command to execute the query
                    cmd.ExecuteNonQuery();
                }
            }

            // create a message box to show that the database has been created
            MessageBox.Show("Database Created");
        }

        // create a function that will add a user to the database
        private void AddUser(string strFirstName, string strLastName, string strUserName, string strPassword)
        {
            // create a connection to the database
            using (SQLiteConnection conn = new SQLiteConnection($"Data Source={strObPath}; Version=3;"))
            {
                // open the connection to the database
                conn.Open();

                // create the insert query
                string strInsertQuery = @"INSERT INTO tblUserId(FirstName, LastName, UserName, passward) 
                                          VALUES(@FirstName, @LastName, @UserName, @passward);";
                
                // create the command
                using (SQLiteCommand cmd = new SQLiteCommand(strInsertQuery, conn))
                {
                    // add the parameters to the command
                    cmd.Parameters.AddWithValue("@FirstName", strFirstName);
                    cmd.Parameters.AddWithValue("@LastName", strLastName);
                    cmd.Parameters.AddWithValue("@UserName", strUserName);
                    cmd.Parameters.AddWithValue("@passward", strPassword);
                    // execute the command
                    cmd.ExecuteNonQuery();
                }
            }            
        }


        // create a function that will load the user from the database
        private void LoadUser()
        {
            // create a connection to the database
            using (SQLiteConnection conn = new SQLiteConnection($"Data Source={strObPath}; Version=3;"))
            {
                // open the connection to the database
                conn.Open();

                // create the select query
                string strSelectQuery = @"SELECT * FROM tblUserId;";

                using (SQLiteDataAdapter adapter = new SQLiteDataAdapter(strSelectQuery, conn))
                {
                    // create a data table to hold the data
                    DataTable dt = new DataTable();

                    // fill the data table with the data from the database
                    adapter.Fill(dt);

                    // set the data source of the data grid view to the data table
                    dgvUserInfo.DataSource = dt;
                }

            }
        }
    }
}
